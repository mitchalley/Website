#!/usr/bin/env python
# coding: utf-8

# In[51]:


import csv
import numpy as np
from matplotlib import pyplot as plt
import math as m
from scipy.cluster.hierarchy import dendrogram, linkage


def load_data(filepath):
    input_file = csv.DictReader(open(filepath))
    file = []
    for n in input_file:
        file.append(n)
    return file

def calc_features(row):
    ret = []
    ret.append(row["Attack"])
    ret.append(row["Sp. Atk"])
    ret.append(row["Speed"])
    ret.append(row["Defense"])
    ret.append(row["Sp. Def"])
    ret.append(row["HP"])
    arr = np.array(ret, dtype=np.int64)
    return arr


def updateDistance(oneR, distMatrix,  twoR):
    sume = len(distMatrix)
    sumrows = distMatrix.size - 2
    i = 0
    current = []
    while sumrows > 0 and i < sume:
        if i == oneR or i == twoR: 
            if i == oneR:
                current.append(0) 
            i += 1
            continue
        firstone = distMatrix[oneR][i]
        secondone = distMatrix[twoR][i]
        filling = max(firstone, secondone)
        current.append(filling) 
        i += 1
        sumrows -= 1
    return current


def hac(features):
    
    trackclusters = []
    totalnumberofpokes = len(features)
    numberofpokes = []
    for industry in range(totalnumberofpokes):
        trackclusters.append(industry)
        numberofpokes.append(1)
    listofpokes = [] 
    for somei in features:
        listofpokes.append(somei) 
    
    listofallpokesin = np.zeros((totalnumberofpokes-1, 4))
    listofpokes = np.array(listofpokes)
    clusterofallpokes = totalnumberofpokes
    indexofzed = 0
    
    matrixofdistances = np.zeros((totalnumberofpokes, totalnumberofpokes))
    
    for indi in range(totalnumberofpokes):
        for indj in range(totalnumberofpokes):
            currentindxofj = features[indj]
            currentindxofi = features[indi]
            
            distance = np.linalg.norm(currentindxofi-currentindxofj) 
            matrixofdistances[indi][indj] = distance
    while indexofzed < totalnumberofpokes-1:
        powerthrust1 = [] 
        indexofi = 0
        powerthrust2 = []
        indexofj = 0 
        findeliteindexi = 0
        sizeofpoke = 0
        findeliteindexj = 1
        mindistance = matrixofdistances[0][1]
        zeta = len(trackclusters)
        for i in range(zeta):
            sizeofpoke+=1
            indexofj = 0
            
            
            
            for j in range(zeta):
                sizeofpoke+=1
                if matrixofdistances[i][j] < mindistance and matrixofdistances[i][j] != 0:
                    powerthrust1 = listofpokes[indexofi] 
                    mindistance = matrixofdistances[i][j] 
                     
                    findeliteindexi = i
                    powerthrust2 = listofpokes[indexofj]
                    findeliteindexj = j 
                if j == (zeta-1) and i == (zeta-1): 
                    
                    if matrixofdistances.size-2 == 2:
                        findeliteindexi = 0
                        findeliteindexj = 1
                        matrixofdistances = updateDistance(findeliteindexi, matrixofdistances, findeliteindexj)
                    else:
                        toAdd = updateDistance(findeliteindexi, matrixofdistances,  findeliteindexj) 
                        matrixofdistances = np.delete(matrixofdistances, findeliteindexj, 1) 
                        matrixofdistances = np.delete(matrixofdistances, findeliteindexj, 0)
                        matrixofdistances[findeliteindexi] = toAdd
                        matrixofdistances[:, findeliteindexi] = toAdd
                    if trackclusters[findeliteindexi] > trackclusters[findeliteindexj]:
                        listofallpokesin[indexofzed][1] = trackclusters[findeliteindexi]
                        listofallpokesin[indexofzed][0] = trackclusters[findeliteindexj]
                        
                    else:
                        listofallpokesin[indexofzed][0] = trackclusters[findeliteindexi]
                        listofallpokesin[indexofzed][1] = trackclusters[findeliteindexj] 
                    currentnumberin2 = trackclusters[findeliteindexj] 
                    currentnumberin = trackclusters[findeliteindexi] 
                    listofallpokesin[indexofzed][2] = mindistance
                    somenumbernamed1 = numberofpokes[currentnumberin] + numberofpokes[currentnumberin2] 
                    numberofpokes.append(somenumbernamed1) 
                    listofallpokesin[indexofzed][3] = somenumbernamed1
                    trackclusters[findeliteindexi] = clusterofallpokes
                    clusterofallpokes += 1
                    deletethisnumber = trackclusters[findeliteindexj]
                    trackclusters.remove(deletethisnumber)
                    indexofzed+=1
                    break
            indexofi += 1
            indexofj += 1
    return listofallpokesin


def imshow_hac(Z):
    dendrogram(Z,leaf_font_size=8.,leaf_rotation=90.,)
    plt.show()


