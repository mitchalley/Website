#!/usr/bin/env python
# coding: utf-8

# In[147]:


import pandas as pd
import csv
import matplotlib.pyplot as plt
import numpy as np
import bs4 as bs
import urllib.request
import sys
from matplotlib.ticker import FormatStrFormatter

if __name__ == '__main__':
    
    sys.argv[1]
    df = pd.read_csv(sys.argv[1])
    for i in range(len(df)):
        df['days'][i] = int(df['days'][i])
    fig, ax = plt.subplots()
    ax.plot(df['year'], df['days'])
    ax.set_xlabel('Year')
    ax.set_ylabel('Number of frozen days')
    plt.yticks(np.arange(30, 180, 30))
    plt.savefig('plot.png')
    
    #Part 3
    X = []
    for i in df['year']:
        X.append([1, i])
    X = np.array(X)
    Y = np.array(df['days'])

    Z = np.matmul(np.transpose(X), X)
    I = np.linalg.inv(Z)
    PI = np.matmul(I, np.transpose(X))
    hat_beta = np.matmul(PI, Y)
    print('Q3a:')
    print(X)
    print('Q3b:')
    print(Y)
    print('Q3c:')
    print(Z)
    print('Q3d:')
    print(I)
    print('Q3e:')
    print(PI)
    print('Q3f:')
    print(hat_beta)

    #Part 4
    beta_zero = hat_beta[0]
    beta_one = hat_beta[1]
    x_test = 2021
    y_test = beta_zero + beta_one * x_test
    print('Q4: ' + str(y_test))

    #Part 5
    if beta_one > 0:
        print('Q5a: >')
    elif beta_one < 0:
        print('Q5a: <')
    else:
        print('Q5a: =')

    print('Q5b: This means that on average, as the year increases, the amount of days that the ice is frozen decreases by', beta_one)

    #Part 6
    neg_beta_zero = 0 - beta_zero
    xstar = neg_beta_zero / beta_one
    print('Q6a:', xstar)
    print('Q6a: This is a compelling prediction because the beta_one value is very small, therefore, it will take an extreme amount of time (roughly 400 years) before lake mendota does not freeze over')



# In[ ]:




